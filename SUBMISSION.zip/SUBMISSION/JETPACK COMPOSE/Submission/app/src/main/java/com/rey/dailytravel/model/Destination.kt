package com.rey.dailytravel.model

class Destination (
    val id: Long,
    val destination: String,
    val image: String,
    val description: String
)