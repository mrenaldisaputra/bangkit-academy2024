package com.rey.dailytravel.data

import com.rey.dailytravel.model.Destination
import com.rey.dailytravel.model.DestinationData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf

class DestinationRepository {
    private val destinations = mutableListOf<Destination>()

    init {
        if (destinations.isEmpty()) {
            destinations.addAll(DestinationData.destinations)
        }
    }

    fun getAllDestinations(): Flow<List<Destination>> {
        return flowOf(destinations)
    }

    fun getDestinationById(destinationId: Long): Destination {
        return destinations.first {
            it.id == destinationId
        }
    }

    fun searchDestination(query: String) = flow {
        val data = destinations.filter {
            it.destination.contains(query, ignoreCase = true)
        }
        emit(data)
    }

    companion object {
        @Volatile
        private var instance: DestinationRepository? = null

        fun getInstance(): DestinationRepository =
            instance ?: synchronized(this) {
                DestinationRepository().apply {
                    instance = this
                }
            }
    }
}