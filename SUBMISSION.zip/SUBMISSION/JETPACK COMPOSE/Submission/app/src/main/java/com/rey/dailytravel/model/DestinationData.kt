package com.rey.dailytravel.model

object DestinationData {
    val destinations = listOf(
        Destination(
            0,
            "Indonesia, Bali",
            "https://images.pexels.com/photos/2166553/pexels-photo-2166553.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Tidak ada tempat lain seperti Bali. Sebuah perpaduan ajaib dari budaya yang berwarna, masyarakat yang ramah, alam yang memukau, berbagai aktivitas, cuaca tropis, cita rasa kuliner, kehidupan malam yang bersemangat, dan akomodasi yang indah. Bali secara teratur dinilai sebagai salah satu destinasi wisata terbaik di dunia – dengan alasan yang sangat baik."
        ),
        Destination(
            1,
            "Perancis, Paris",
            "https://images.pexels.com/photos/1308940/pexels-photo-1308940.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Rasakan suasana romantis Paris. Kunjungi landmark ikonik seperti Menara Eiffel, jelajahi museum seni, dan nikmati kuliner Prancis."
        ),
        Destination(
            2,
            "Jepang, Kyoto",
            "https://images.pexels.com/photos/1673978/pexels-photo-1673978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Merupakan diri Anda dalam pesona tradisional Kyoto. Jelajahi kuil bersejarah, berjalan-jalan di kebun bambu, dan nikmati upacara teh Jepang yang otentik."
        ),
        Destination(
            3,
            "US, New York City",
            "https://images.pexels.com/photos/4331280/pexels-photo-4331280.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Temukan kota yang tidak pernah tidur. Kunjungi Times Square, jelajahi Central Park, dan rasakan keberagaman budaya dan hiburan New York City."
        ),
        Destination(
            4,
            "Afrika Selatan, Cape Town",
            "https://images.pexels.com/photos/4873264/pexels-photo-4873264.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Jelajahi pemandangan yang memukau di Cape Town. Kunjungi Table Mountain, nikmati safari satwa liar, dan rasakan sejarah dan budaya kaya Afrika Selatan."
        ),
        Destination(
            5,
            "Australia, Sydney",
            "https://images.pexels.com/photos/2193300/pexels-photo-2193300.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Rasakan kehidupan kota yang bersemangat dan pemandangan yang menakjubkan di Sydney. Kunjungi Opera House Sydney, bersantai di Bondi Beach, dan jelajahi kehidupan liar Australia yang unik."
        ),
        Destination(
            6,
            "Maroko, Marrakech",
            "https://images.pexels.com/photos/15360706/pexels-photo-15360706/free-photo-of-landscape-of-palm-trees-and-the-atlas-mountains-in-marrakech-morocco.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Jelajahi pasar ramai, kunjungi istana bersejarah, dan nikmati cita rasa masakan Maroko."
        ),
        Destination(
            7,
            "Brasil, Rio de Janeiro",
            "https://images.pexels.com/photos/351283/pexels-photo-351283.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Temukan getaran energik Rio de Janeiro. Nikmati Karnaval terkenal, bersantai di Copacabana Beach, dan jelajahi patung ikonik Christ the Redeemer."
        ),
        Destination(
            8,
            "Korea Selatan, Seoul",
            "https://images.pexels.com/photos/373290/pexels-photo-373290.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Rasakan perpaduan modern dan tradisional Seoul. Jelajahi pasar jalanan yang ramai, kunjungi istana kuno, dan nikmati cita rasa masakan Korea yang lezat."
        ),
        Destination(
            9,
            "Italia, Venice",
            "https://images.pexels.com/photos/1144265/pexels-photo-1144265.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Masuki kanal romantik Venice. Naik gondola, kunjungi landmark bersejarah seperti Basilika Santo Markus, dan nikmati cita rasa masakan Italia yang otentik."
        ),
        Destination(
            10,
            "Republik Ceko, Prague",
            "https://images.pexels.com/photos/126292/pexels-photo-126292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Jelajahi pesona sejarah Prague. Kunjungi Hradcany Castle, berjalan-jalan di Charles Bridge, dan nikmati atmosfer kota tua yang indah."
        ),
        Destination(
            11,
            "Peru, Cusco",
            "https://images.pexels.com/photos/2929906/pexels-photo-2929906.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Temukan warisan Inca di Cusco. Kunjungi Machu Picchu, jelajahi Sacred Valley, dan nikmati keindahan alam Peru."
        ),
        Destination(
            12,
            "Uni Emirat Arab, Dubai",
            "https://images.pexels.com/photos/325193/pexels-photo-325193.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Rasakan kemewahan Dubai. Kunjungi Burj Khalifa, jelajahi The Dubai Mall, dan nikmati kehidupan malam yang gemilang."
        ),
        Destination(
            13,
            "Selandia Baru, Auckland",
            "https://images.pexels.com/photos/18201091/pexels-photo-18201091/free-photo-of-auckland-at-sunset.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Jelajahi keindahan Selandia Baru di Auckland. Naik ke Sky Tower, kunjungi Waiheke Island, dan nikmati kegiatan luar ruangan yang menakjubkan."
        ),
        Destination(
            14,
            "Swedia, Stockholm",
            "https://images.pexels.com/photos/1529040/pexels-photo-1529040.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
            "Nikmati pesona arsitektur dan budaya Stockholm. Jelajahi Gamla Stan, kunjungi The Vasa Museum, dan rasakan kehidupan kota yang tenang di tepi laut."
        )
    )
}