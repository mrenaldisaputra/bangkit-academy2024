package com.rey.dailytravel.ui.screen.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rey.dailytravel.R
import com.rey.dailytravel.di.Injection
import com.rey.dailytravel.model.Destination
import com.rey.dailytravel.ui.ViewModelFactory
import com.rey.dailytravel.ui.common.UiState
import com.rey.dailytravel.ui.components.DestinationListItem
import com.rey.dailytravel.ui.components.EmptyItem
import com.rey.dailytravel.ui.components.SearchView

@Composable
fun SearchScreen(
    modifier: Modifier = Modifier,
    viewModel: SearchViewModel = viewModel(
        factory = ViewModelFactory(Injection.providerRepository())
    ),
    navigateToDetail: (Long) -> Unit,
) {
    val query by viewModel.query
    viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
        when (uiState) {
            is UiState.Loading -> {
                viewModel.searchDestination(query)
            }

            is UiState.Success -> {
                SearchContent(
                    query = query,
                    onQueryChange = viewModel::searchDestination,
                    listDestination = uiState.data,
                    modifier = modifier,
                    navigateToDetail = navigateToDetail,
                )
            }

            is UiState.Error -> {}
        }
    }
}

@Composable
fun SearchContent(
    query: String,
    onQueryChange: (String) -> Unit,
    listDestination: List<Destination>,
    modifier: Modifier = Modifier,
    navigateToDetail: (Long) -> Unit,
) {
    Column (modifier = modifier) {
        SearchView(
            query = query,
            onQueryChange = onQueryChange,
        )
        if (listDestination.isNotEmpty()) {
            ListItem(
                listDestination = listDestination,
                navigateToDetail = navigateToDetail
            )
        } else {
            EmptyItem(
                text = stringResource(id = R.string.empty_item)
            )
        }
    }
}


@Composable
fun ListItem(
    listDestination: List<Destination>,
    modifier: Modifier = Modifier,
    navigateToDetail: (Long) -> Unit,
) {
    LazyColumn {
        items(listDestination) { data ->
            DestinationListItem(
                destination = data.destination,
                image = data.image,
                modifier = modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { navigateToDetail(data.id) }
            )
        }
    }
}
