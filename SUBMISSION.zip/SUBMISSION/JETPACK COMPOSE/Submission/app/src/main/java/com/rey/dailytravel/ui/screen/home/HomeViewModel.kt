package com.rey.dailytravel.ui.screen.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rey.dailytravel.data.DestinationRepository
import com.rey.dailytravel.model.Destination
import com.rey.dailytravel.ui.common.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: DestinationRepository
) : ViewModel() {
    private val _uiState: MutableStateFlow<UiState<List<Destination>>> = MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<List<Destination>>>
        get() = _uiState

    fun getAllDestinations() {
        viewModelScope.launch {
            repository.getAllDestinations()
                .catch {
                    _uiState.value = UiState.Error(it.message.toString())
                }
                .collect { destinations ->
                    _uiState.value = UiState.Success(destinations)
                }
        }
    }
}