package com.rey.dailytravel.ui.screen.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rey.dailytravel.data.DestinationRepository
import com.rey.dailytravel.model.Destination
import com.rey.dailytravel.ui.common.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DetailViewModel(
    private val repository: DestinationRepository,
) : ViewModel() {
    private val _uiState: MutableStateFlow<UiState<Destination>> =
        MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<Destination>>
        get() = _uiState

    fun getDestinationByid(destinationId: Long) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            _uiState.value = UiState.Success(repository.getDestinationById(destinationId))
        }
    }
}