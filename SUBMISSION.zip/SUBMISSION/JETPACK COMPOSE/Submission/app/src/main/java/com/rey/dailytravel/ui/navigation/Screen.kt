package com.rey.dailytravel.ui.navigation

sealed class Screen(val route: String) {
    object Home: Screen("home")
    object Search: Screen("search")
    object Profile: Screen("profile")
    object DetailDestination : Screen("home/{destinationId}") {
        fun createRoute(destinationId: Long) = "home/$destinationId"
    }
}