package com.rey.dailytravel.di

import com.rey.dailytravel.data.DestinationRepository

object Injection {
    fun providerRepository(): DestinationRepository {
        return DestinationRepository.getInstance()
    }
}