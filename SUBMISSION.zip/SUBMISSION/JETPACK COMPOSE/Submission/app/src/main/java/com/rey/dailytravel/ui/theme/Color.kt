package com.rey.dailytravel.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFBCEAFF)
val PurpleGrey80 = Color(0xFFC2DCDA)
val Pink80 = Color(0xFFE3B8EF)

val Purple40 = Color(0xFFA4505A)
val PurpleGrey40 = Color(0xFF71715B)
val Pink40 = Color(0xFF7D5252)