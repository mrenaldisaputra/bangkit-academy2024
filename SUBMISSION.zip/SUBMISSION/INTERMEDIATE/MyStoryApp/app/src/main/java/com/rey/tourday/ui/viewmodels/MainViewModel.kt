package com.rey.tourday.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.rey.tourday.data.local.pref.UserModel
import com.rey.tourday.data.remote.response.ListStoryItem
import com.rey.tourday.data.repository.StoryRepository
import com.rey.tourday.utils.Event
import kotlinx.coroutines.launch

class MainViewModel(private val repository: StoryRepository) : ViewModel() {
    val toast: LiveData<Event<String>> = repository.toast
    val loading: LiveData<Boolean> = repository.loading
    val story: LiveData<PagingData<ListStoryItem>> =
        repository.getStories().cachedIn(viewModelScope)


    fun getSession(): LiveData<UserModel> {
        return repository.getSession()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }
}