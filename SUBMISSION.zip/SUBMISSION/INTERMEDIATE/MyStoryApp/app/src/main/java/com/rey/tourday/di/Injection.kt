package com.rey.tourday.di

import android.content.Context
import com.rey.tourday.data.local.pref.UserPreferences
import com.rey.tourday.data.local.pref.dataStore
import com.rey.tourday.data.repository.StoryRepository
import com.rey.tourday.data.remote.networking.ApiConfig

object Injection {
    fun provideRepository(context: Context): StoryRepository {
        val pref = UserPreferences.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return StoryRepository.getInstance(pref, apiService)
    }
}