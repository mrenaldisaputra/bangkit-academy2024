package com.rey.tourday.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.rey.tourday.data.local.pref.UserModel
import com.rey.tourday.data.repository.StoryRepository
import java.io.File

class AddStoryViewModel(private val repository: StoryRepository) : ViewModel() {
    fun uploadStory(token: String, file: File, description: String) =
        repository.uploadStory(token, file, description)

    fun getSession(): LiveData<UserModel> {
        return repository.getSession()
    }
}