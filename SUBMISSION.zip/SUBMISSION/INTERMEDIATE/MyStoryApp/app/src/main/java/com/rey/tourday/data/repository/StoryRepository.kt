package com.rey.tourday.data.repository

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.liveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.rey.tourday.data.local.model.ResultState
import com.rey.tourday.data.local.pref.UserModel
import com.rey.tourday.data.local.pref.UserPreferences
import com.rey.tourday.data.remote.response.LoginResponse
import com.rey.tourday.data.remote.response.RegisterResponse
import com.rey.tourday.data.remote.networking.ApiService
import com.rey.tourday.data.remote.response.ListStoryItem
import com.rey.tourday.data.remote.response.StoryResponse
import com.rey.tourday.data.remote.response.StoryUploadResponse
import com.rey.tourday.utils.Event
import com.rey.tourday.utils.StoryPagingSource
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.HttpException
import retrofit2.Response
import java.io.File

class StoryRepository private constructor(
    private val userPreferences: UserPreferences,
    private val apiService: ApiService,
) {
    private val _registerResponse = MutableLiveData<RegisterResponse>()
    val registerResponse: LiveData<RegisterResponse> = _registerResponse

    private val _loginResponse = MutableLiveData<LoginResponse>()
    val loginResponse: LiveData<LoginResponse> = _loginResponse

    private val _toast = MutableLiveData<Event<String>>()
    val toast: LiveData<Event<String>> = _toast

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _dataStory = MutableLiveData<StoryResponse>()
    val dataStory: LiveData<StoryResponse> = _dataStory

    suspend fun saveSession(user: UserModel) {
        userPreferences.saveSession(user)
    }

    fun getSession(): LiveData<UserModel> {
        return userPreferences.getSession().asLiveData()
    }

    suspend fun login() {
        userPreferences.login()
    }

    suspend fun logout() {
        userPreferences.logout()
    }

    fun registerUser(name: String, email: String, password: String) {
        _loading.value = true
        val client = apiService.register(name, email, password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>,
            ) {
                if (response.isSuccessful && response.body() != null) {
                    _toast.value = Event(response.body()?.message.toString())
                    _registerResponse.value = response.body()
                } else {
                    if (response.code() == 400) {
                        val errorBody = response.errorBody()?.string()
                        try {
                            val errorResponse = JSONObject(errorBody)
                            val errorMessage = errorResponse.optString("message")
                            _toast.value = Event(errorMessage)
                        } catch (e: Exception) {
                            _toast.value = Event("Bad Request: Failed to parse error message")
                        }
                    } else {
                        _toast.value = Event(response.message().toString())
                    }
                }
                _loading.value = false
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                _loading.value = false
                _toast.value = Event(t.message.toString())
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }


    fun loginUser(email: String, password: String) {
        _loading.value = true
        val client = apiService.login(email, password)
        client.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    _toast.value = Event(response.body()?.message.toString())
                    _loginResponse.value = response.body()
                } else {
                    _toast.value = Event(response.message().toString())
                }
                _loading.value = false
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                _loading.value = false
                _toast.value = Event(t.message.toString())
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

    fun getStories(): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                StoryPagingSource(userPreferences, apiService)
            }
        ).liveData
    }


    fun uploadStory(token: String, imageFile: File, description: String) = liveData {
        emit(ResultState.Loading)
        val requestBody = description.toRequestBody("text/plain".toMediaType())
        val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo",
            imageFile.name,
            requestImageFile
        )
        try {
            val successResponse = apiService.uploadStory(token, multipartBody, requestBody)
            emit(ResultState.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, StoryUploadResponse::class.java)
            emit(ResultState.Error(errorResponse.message))
        }
    }

    fun getStoriesWithLocation(token: String) {
        _loading.value = true
        val client = apiService.getStoriesWithLocation(token)
        client.enqueue(object : Callback<StoryResponse> {
            override fun onResponse(call: Call<StoryResponse>, response: Response<StoryResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    _dataStory.value = response.body()
                } else {
                    _toast.value = Event(response.message().toString())
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
                _loading.value = false
            }

            override fun onFailure(call: Call<StoryResponse>, t: Throwable) {
                _loading.value = false
                _toast.value = Event(t.message.toString())
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null
        fun getInstance(
            userPreference: UserPreferences,
            apiService: ApiService,
        ): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(userPreference, apiService)
            }.also { instance = it }
    }
}
