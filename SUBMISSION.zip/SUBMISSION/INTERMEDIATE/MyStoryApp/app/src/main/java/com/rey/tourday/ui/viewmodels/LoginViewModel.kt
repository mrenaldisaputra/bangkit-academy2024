package com.rey.tourday.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rey.tourday.data.local.pref.UserModel
import com.rey.tourday.data.remote.response.LoginResponse
import com.rey.tourday.data.repository.StoryRepository
import com.rey.tourday.utils.Event
import kotlinx.coroutines.launch

class LoginViewModel(private val repository: StoryRepository) : ViewModel() {
    val toast: LiveData<Event<String>> = repository.toast
    val loading: LiveData<Boolean> = repository.loading
    val loginResponse: LiveData<LoginResponse> = repository.loginResponse

    fun saveSession(user: UserModel) {
        viewModelScope.launch {
            repository.saveSession(user)
        }
    }

    fun login() {
        viewModelScope.launch {
            repository.login()
        }
    }

    fun loginUser(email: String, password: String) {
        viewModelScope.launch {
            repository.loginUser(email, password)
        }
    }
}
