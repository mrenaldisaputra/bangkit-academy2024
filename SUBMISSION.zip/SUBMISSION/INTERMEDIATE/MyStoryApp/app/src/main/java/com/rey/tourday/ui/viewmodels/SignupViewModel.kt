package com.rey.tourday.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rey.tourday.data.remote.response.RegisterResponse
import com.rey.tourday.data.repository.StoryRepository
import com.rey.tourday.utils.Event
import kotlinx.coroutines.launch

class SignupViewModel(private val repository: StoryRepository) : ViewModel() {
    val toast: LiveData<Event<String>> = repository.toast
    val loading: LiveData<Boolean> = repository.loading
    val registerResponse: LiveData<RegisterResponse> = repository.registerResponse

    fun registerUser(name: String, email: String, password: String) {
        viewModelScope.launch {
            repository.registerUser(name, email, password)
        }
    }
}
