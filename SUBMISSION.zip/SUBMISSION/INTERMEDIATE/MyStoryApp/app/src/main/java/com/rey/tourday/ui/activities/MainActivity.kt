package com.rey.tourday.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.rey.tourday.ui.adapters.LoadingStateAdapter
import com.rey.tourday.ui.adapters.StoryAdapter
import com.rey.tourday.utils.ViewModelFactory
import com.rey.tourday.ui.viewmodels.MainViewModel
import com.rey.tourday.R
import com.rey.tourday.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val mainViewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding
    private lateinit var storyAdapter: StoryAdapter
    private var token = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.visibility = View.INVISIBLE

        setupUser()
        setupAction()
        setupAdapter()
    }

    private fun setupUser() {
        showLoading()
        mainViewModel.getSession().observe(this@MainActivity) {
            token = it.token
            if (!it.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                setupData()
                binding.root.visibility = View.VISIBLE
            }
            showToast()
        }
    }

    private fun setupAction() {
        binding.topAppBar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.mapsButton -> {
                    navigateToMaps()
                    true
                }
                R.id.logoutButton -> {
                    mainViewModel.logout()
                    finishAffinity()
                    true
                }
                else -> false
            }
        }
        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddStoryActivity::class.java))
        }
    }

    private fun setupData() {
        mainViewModel.story.observe(this@MainActivity) { data ->
            storyAdapter.submitData(lifecycle, data)
        }
    }

    private fun setupAdapter() {
        initializeStoryAdapter()
        initializeRecyclerView()
    }

    private fun initializeRecyclerView() {
        binding.rvStory.layoutManager = LinearLayoutManager(this@MainActivity)
        binding.rvStory.adapter = storyAdapter.withLoadStateFooter(
            footer = LoadingStateAdapter {
                storyAdapter.retry()
            }
        )
    }

    private fun initializeStoryAdapter() {
        storyAdapter = StoryAdapter()
    }

    private fun navigateToMaps() {
        startActivity(Intent(this, MapsActivity::class.java))
    }

    private fun showToast() {
        mainViewModel.toast.observe(this) {
            it.getContentIfNotHandled()?.let { toast ->
                Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showLoading() {
        mainViewModel.loading.observe(this) {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }
}