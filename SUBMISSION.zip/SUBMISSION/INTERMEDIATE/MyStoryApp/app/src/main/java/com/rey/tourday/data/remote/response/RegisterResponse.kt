package com.rey.tourday.data.remote.response

import com.google.gson.annotations.SerializedName

data class RegisterResponse(
    @SerializedName("status") val error: Boolean,
    @SerializedName("message") val message: String,
)
