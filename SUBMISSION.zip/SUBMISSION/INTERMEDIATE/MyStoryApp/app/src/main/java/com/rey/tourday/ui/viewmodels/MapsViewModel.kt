package com.rey.tourday.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rey.tourday.data.local.pref.UserModel
import com.rey.tourday.data.remote.response.StoryResponse
import com.rey.tourday.data.repository.StoryRepository
import kotlinx.coroutines.launch

class MapsViewModel(private val repository: StoryRepository) : ViewModel() {
    val dataStory: LiveData<StoryResponse> = repository.dataStory

    fun getListStoriesWithLocation(token: String) {
        viewModelScope.launch {
            repository.getStoriesWithLocation(token)
        }
    }

    fun getSession(): LiveData<UserModel> {
        return repository.getSession()
    }
}