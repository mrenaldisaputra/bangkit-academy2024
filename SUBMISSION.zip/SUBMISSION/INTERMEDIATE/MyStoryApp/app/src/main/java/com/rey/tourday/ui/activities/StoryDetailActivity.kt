package com.rey.tourday.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.rey.tourday.data.remote.response.ListStoryItem
import com.rey.tourday.R
import com.rey.tourday.databinding.ActivityStoryDetailBinding

class StoryDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStoryDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupData()
    }

    private fun setupData() {
        @Suppress("DEPRECATION") val storyItem =
            intent.getParcelableExtra<ListStoryItem>("storyItem")
        binding.apply {
            Glide.with(this@StoryDetailActivity)
                .load(storyItem?.photoUrl)
                .centerCrop()
                .apply(
                    RequestOptions
                        .placeholderOf(R.drawable.loading_spinner)
                )
                .into(imageView)
            username.text = storyItem?.name
            description.text = storyItem?.description
        }
    }
}