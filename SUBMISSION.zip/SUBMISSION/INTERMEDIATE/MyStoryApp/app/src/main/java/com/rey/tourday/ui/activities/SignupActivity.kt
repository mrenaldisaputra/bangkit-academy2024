package com.rey.tourday.ui.activities

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.rey.tourday.utils.ViewModelFactory
import com.rey.tourday.ui.viewmodels.SignupViewModel
import com.rey.tourday.R
import com.rey.tourday.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding
    private val signupViewModel by viewModels<SignupViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupAction()
        playAnimation()
    }

    private fun setupAction() {
        binding.apply {
            signupButton.setOnClickListener {
                val nameIsEmpty = nameEditText.text!!.isEmpty()
                val emailIsEmpty = emailEditText.text!!.isEmpty()
                val passwordIsEmpty = passwordEditText.text!!.isEmpty()

                if (nameIsEmpty) {
                    nameEditText.error = binding.root.context.getString(R.string.required_field)
                }
                if (emailIsEmpty) {
                    emailEditText.error = binding.root.context.getString(R.string.required_field)
                }
                if (passwordIsEmpty) {
                    passwordEditText.error = binding.root.context.getString(R.string.required_field)
                }
                if (!nameIsEmpty && !emailIsEmpty && !passwordIsEmpty) {
                    postData()
                    showLoading()
                    showToast()
                    navigateToLogin()
                }
            }
            backButton.setOnClickListener {
                val intent = Intent(this@SignupActivity, WelcomeActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun postData() {
        binding.apply {
            signupViewModel.registerUser(
                nameEditText.text.toString(),
                emailEditText.text.toString(),
                passwordEditText.text.toString()
            )
        }
    }

    private fun showToast() {
        signupViewModel.toast.observe(this) {
            it.getContentIfNotHandled()?.let { toast ->
                Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun navigateToLogin() {
        signupViewModel.registerResponse.observe(this) { response ->
            if (!response.error) {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }

    private fun showLoading() {
        signupViewModel.loading.observe(this) {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        }
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.titleTextView, View.ALPHA, 1f).setDuration(100)
        val name = ObjectAnimator.ofFloat(binding.nameTextView, View.ALPHA, 1f).setDuration(100)
        val inputName =
            ObjectAnimator.ofFloat(binding.nameEditTextLayout, View.ALPHA, 1f).setDuration(100)
        val email = ObjectAnimator.ofFloat(binding.emailTextView, View.ALPHA, 1f).setDuration(100)
        val inputEmail =
            ObjectAnimator.ofFloat(binding.emailEditTextLayout, View.ALPHA, 1f).setDuration(100)
        val password =
            ObjectAnimator.ofFloat(binding.passwordTextView, View.ALPHA, 1f).setDuration(100)
        val inputPassword =
            ObjectAnimator.ofFloat(binding.passwordEditTextLayout, View.ALPHA, 1f).setDuration(100)
        val signup = ObjectAnimator.ofFloat(binding.signupButton, View.ALPHA, 1f).setDuration(100)

        AnimatorSet().apply {
            playSequentially(
                title,
                name,
                inputName,
                email,
                inputEmail,
                password,
                inputPassword,
                signup
            )
            startDelay = 100
        }.start()
    }
}