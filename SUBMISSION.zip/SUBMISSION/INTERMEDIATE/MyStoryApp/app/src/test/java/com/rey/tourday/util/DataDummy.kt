package com.rey.tourday.util

import com.rey.tourday.data.remote.response.ListStoryItem

object DataDummy {

    fun generateDummyStory(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..20) {
            val story = ListStoryItem(
                "https://www.pexels.com/photo/skyscraper-towering-over-crowd-on-street-in-downtown-15509517/",
                "2023-10-28T10:50:22Z",
                "Story $i",
                "This is a sample description for Story $i",
                0.0,
                i.toString(),
                0.0
            )
            items.add(story)
        }
        return items
    }
}