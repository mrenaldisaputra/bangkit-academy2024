package com.example.mygithubuser.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.transform.CircleCropTransformation
import com.example.mygithubuser.databinding.ItemUserBinding
import coil.load
import com.example.mygithubuser.data.response.User

class UserAdapter(
    private val data: MutableList<User.Item> = mutableListOf(),
    private val listener: (User.Item) -> Unit
) :

    RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    fun setData(data: MutableList<User.Item>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    class UserViewHolder(private val v: ItemUserBinding) : RecyclerView.ViewHolder(v.root) {
        fun bind(item: User.Item) {
            v.ivUser.load(item.avatar_url) {
                transformations(CircleCropTransformation())
            }
            v.tvUsername.text = item.login
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.UserViewHolder =
        UserAdapter.UserViewHolder(
            ItemUserBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )


    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val item = data[position]
        holder.bind(item)
        holder.itemView.setOnClickListener {
            listener(item)
        }
    }

    override fun getItemCount(): Int = data.size

}