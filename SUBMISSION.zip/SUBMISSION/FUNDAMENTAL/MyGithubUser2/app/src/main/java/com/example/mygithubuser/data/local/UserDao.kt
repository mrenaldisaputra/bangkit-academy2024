package com.example.mygithubuser.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.mygithubuser.data.response.User

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: User.Item)

    @Query("SELECT * FROM user")
    fun loadAll(): LiveData<MutableList<User.Item>>

    @Query("SELECT * FROM user WHERE id LIKE :id LIMIT 1")
    fun findById(id: Int): User.Item

    @Delete
    fun delete(user: User.Item)


}