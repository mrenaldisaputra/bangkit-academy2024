package com.example.mygithubuser.data.retrofit

import com.example.mygithubuser.data.response.ResponseDetailUser
import com.example.mygithubuser.data.response.User
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.QueryMap


interface ApiService {

    @JvmSuppressWildcards
    @GET("users")
    @Headers("Authorization: token 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")
    suspend fun getUserGithub(): MutableList<User.Item>

    @JvmSuppressWildcards
    @GET("users/{username}")
    @Headers("Authorization: token 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")
    suspend fun getDetailUserGithub(@Path("username") username: String): ResponseDetailUser

    @JvmSuppressWildcards
    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    suspend fun getFollowersUserGithub(@Path("username") username: String): MutableList<User.Item>

    @JvmSuppressWildcards
    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    suspend fun getFollowingUserGithub(@Path("username") username: String): MutableList<User.Item>

    @JvmSuppressWildcards
    @GET("search/users")
    @Headers("Authorization: token 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")
    suspend fun getSearchUserGithub(@QueryMap params: Map<String, Any>): User
}